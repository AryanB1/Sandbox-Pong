import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class Chase extends PApplet {

//Global Variables and Objects
int NumberOfStars = 5; //Verseion of a Static Variable in Pure Java, final here
Ball[] stars = new Ball[NumberOfStars]; //Processing Requires #, Pure Java allows static variable
//
int appWidth, appHeight; //final variables
int smallerDisplayDimension; //final variable
//
Boolean redo=true;
//
public void setup() {
   //fullScreen, displayWidth, displayHeight
  //Protrait, not landscape or square
  display();
  starsPopulation();
  //
}//End setup
//
public void draw() {
  background(0);
  for ( Ball star : stars ) { //See FOR-Each Example for explanation
    star.drawStar();
  }//End FOR
}//End draw
//
public void keyPressed(){
}//End keyPressed
//
public void mousePressed() {
  for (int i=0; i<stars.length; i++) {
    stars[i].setTargetX(mouseX); //Value of mouse-click
    stars[i].setTargetY(mouseY); //Value of mouse-click
  }//End FOR
}//End mousePressed
//End Main Driver
//Starts private ball class
private class Ball
{
  //Global Variables
  private float x, y, diameter, xStart, yStart, xDirection, yDirection;
  private int colour, colourReset=0xffFFFFFF;
  private int xSpeed, ySpeed;
  public int targetX=50, targetY=50;
  public boolean xTargetSet=false, yTargetSet=false;
  //starts public ball class + constructor
  public Ball (float widthParameter, float heightParameter, float diameterParameter) {
    //Sets Parameters
    //Ball start locations
    x = PApplet.parseInt ( widthParameter ); //casting here is truncating decimals
    y = PApplet.parseInt ( heightParameter );
    diameter = PApplet.parseInt ( diameterParameter );
    //For the colours, everything is randomized between 100 and 200
    //This is because through testing, I found that the 0-100, 200-255 range was a bit too solid
    //In comparison, since the 100-200 range is smaller, all the colours have a relatively similar level of colour solidness
    //This in turn makes it easier on the eyes
    //Also the night mode commonly creates a greenish color which gives a hacker vibe
    colour = color( random(100, 200), random(100, 200), random(100, 200) );
  }
  //End Constructor + public ball class
  //start draw()
  public void balldraw() {
    //Fills ball with colour
    fill(colour);
    //draws ball
    ellipse(x, y, diameter, diameter);
    //resets fill
    fill(colourReset);
    //checks for screen saver
  }
  //End draw()
  //start move()
  public void drawStar() {
    balldraw();
    starChase();
  }//End drawStar
  public void starChase() {
    //sets movement to a target location if a click has been made
    if(xTargetSet == true && yTargetSet == true){
      float xNeeded = x - targetX;
      float yNeeded = y - targetY;
      xNeeded = xNeeded/60;
      yNeeded = yNeeded/60;
      if ( x != targetX) x -= xNeeded;
      if(y != targetY) y -= yNeeded;
      //Due to the nature of the algorithm, it will infinitely move close to the point clicked
      //This correction is set, so if the circle is unnoticably close to the target point
      //The ball will correct itself into the right position.
      //When implemented in OOP pong, this will help make sure the game runs smoothly
      //if a large number of balls are created
      if(x >= targetX-0.5f && x < targetX || x <= targetX+0.5f && x > targetX) x = targetX;
      if(y >= targetY-0.5f && y < targetY || y <= targetY+0.5f && y > targetY) y = targetY;
    }
  }
  //
  public void setTargetX(int iParameter) {
    targetX = iParameter;
    xTargetSet = true;
  }//End setTargetX
  //
  public void setTargetY(int iParameter) {
    targetY = iParameter;
    yTargetSet = true;
  }//End setTargetY
  // end bounce()
}
  //End Ball class
public void display() {
  println (width, height, displayWidth, displayHeight);
  appWidth = width; // switch with displayWidth
  appHeight = height; // switch with displayHeight
  smallerDisplayDimension = ( appWidth <= appHeight ) ? appWidth : appHeight;
}//End Display
public void starsPopulation() {
  int geometry = ( displayWidth <= displayHeight ) ? displayWidth : displayHeight;  
  for (int i=0; i<stars.length; i++) {
    //Randomly choose parameters
    float diameterRandom = random ( geometry*1/8, geometry*1/4); //Consider user Input (eye sentitivity)
    float xRandom = random ( diameterRandom*1/2, displayWidth-diameterRandom*1/2 ); //No stars in net
    float yRandom = random ( diameterRandom*1/2, displayHeight-diameterRandom*1/2 ); //Entire displayHeight OK
    stars[i] = new Ball (xRandom, yRandom, diameterRandom);
    /* Switched the loops to normal if statements, since the loops seemed
    unnecessary, and the if statements are more efficient
    */ 
    if ( xRandom-diameterRandom*1/2 > stars[i].x && xRandom+diameterRandom*1/2 < stars[i].x ) {
      xRandom = random ( diameterRandom*1/2, displayWidth-diameterRandom*1/2 );
      stars[i] = new Ball (xRandom, yRandom, diameterRandom);
      }
    if ( yRandom-diameterRandom*1/2 > stars[i].x && yRandom+diameterRandom*1/2 < stars[i].x ) {
      yRandom = random ( diameterRandom*1/2, displayHeight-diameterRandom*1/2 );
      stars[i] = new Ball (xRandom, yRandom, diameterRandom);
    //
  }//End FOR
  }
  for (int i=0; i<stars.length; i++) {
  for ( int j=stars.length-1; j>i; j--) {
    /*Checks distance between stars and then ensures that the distance is greater
     than the average diameter of the two stars. If the average diameter is larger
     than the distance, a new ball is made, and the algorithm repeats
    */
    if(dist(stars[i].x, stars[i].y, stars[j].x, stars[j].y) <= ((stars[i].diameter+stars[j].diameter)*1/2)){
      float diameterRandom = random ( geometry*1/8, geometry*1/4); //Consider user Input (eye sentitivity)
      float xRandom = random ( diameterRandom*1/2, displayWidth-diameterRandom*1/2 ); //No stars in net
      float yRandom = random ( diameterRandom*1/2, displayHeight-diameterRandom*1/2 ); //Entire displayHeight OK
      stars[i] = new Ball (xRandom, yRandom, diameterRandom);
      i = 0;
      j = stars.length;
    }
    }//End nested FOR
  }//End Final Check
}//End setup
  public void settings() {  fullScreen(); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--present", "--window-color=#666666", "--stop-color=#cccccc", "Chase" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
